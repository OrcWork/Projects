﻿namespace StrategySample.Fly
{
    public interface IFlyable
    {
        void Fly();
    }
}

﻿namespace StrategySample.Quack
{
    public interface IQuackable
    {
        void Quack();
    }
}
